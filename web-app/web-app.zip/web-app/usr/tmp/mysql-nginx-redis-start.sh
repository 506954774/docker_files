echo "starting mysql..."
service mysql start
sleep 1s
redis-server /etc/redis.conf &
echo "starting redis..."
sleep 1s
nginx -c  /etc/nginx/nginx.conf
echo "starting nginx..."
sleep 1s
echo "mysql,redis,nginx: started successfully!"

