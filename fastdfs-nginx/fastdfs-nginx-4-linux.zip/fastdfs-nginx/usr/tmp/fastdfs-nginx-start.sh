echo "starting tracker..."
/etc/init.d/fdfs_trackerd /etc/fdfs/tracker.conf start
sleep 1s
/etc/init.d/fdfs_trackerd   start
echo "starting storaged..."
/etc/init.d/fdfs_storaged /etc/fdfs/storage.conf start
sleep 1s
/etc/init.d/fdfs_storaged start    
sleep 1s
echo "starting nginx..."
cd /usr/local/src/nginx/objs/
./nginx -c /etc/nginx/nginx.conf
sleep 1s
echo "tracker,storaged,nginx: started successfully!"

